package demo.pkg.test;

import demo.pkg.Account;
import org.junit.Test;
import org.mockito.Mock;

import static org.junit.Assert.*;

public class AccountTest {

    @Mock
    Account cMock;

    @Test
    public void testValidatePin() {
        Account c = new Account(123456, 1728, 100, 10000);

        assertTrue(c.validatePIN(1728));
        assertEquals(c.getAccountNumber(), 123456);
        assertNotEquals(c.getAccountNumber(), 123457);
    }

    @Test
    public void testAvailableBalance() {
        Account c = new Account(123456, 1728, 100, 10000);

        assertEquals(c.getAvailableBalance(), 100);
        assertNotEquals(c.getAvailableBalance(), 1006);

    }


    @Test
    public void testGetTotalBalance() {
        Account c = new Account(123456, 1728, 100, 10000);
        assertNotEquals(c.getTotalBalance(), 10900);
        assertEquals(c.getTotalBalance(), 10000);
    }

    @Test
    public void testCredit() {
        Account c = new Account(123456, 1728, 100, 10000);
        c.credit(100);
        assertNotEquals(c.getTotalBalance() + 100, 10000);
        assertEquals(c.getTotalBalance() + 100, 10000);

    }

    @Test
    public void testDebit() {
        Account c = new Account(123456, 1728, 100, 10000);
        c.credit(100);
        assertNotEquals(c.getTotalBalance() + 100, 10000);
        assertEquals(c.getTotalBalance() + 100, 10000);

    }

    @Test
    public void testGetAccountNumber() {
        Account c = new Account(123456, 1728, 100, 10000);
        assertNotEquals(c.getAccountNumber(), 123456);
        assertEquals(c.getAccountNumber() + 100, 10000);

    }


}