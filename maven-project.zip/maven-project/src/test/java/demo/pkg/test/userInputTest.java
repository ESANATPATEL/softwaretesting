/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.pkg.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import demo.pkg.*;
import java.io.ByteArrayInputStream;

/**
 *
 * @author Sanat Kumar Patel
 */
public class userInputTest {
    
    public userInputTest() {
    }
    
    @Test
    public void Test(){
        ATM test = new ATM();
        String simulatedinput = 15000 + "";
        ByteArrayInputStream in = new ByteArrayInputStream("MENU".getBytes());
        System.setIn(in);
        assertFalse(test.userInput("BALANCE"));
        assertFalse(test.userInput("DEFAULT"));
        in = new ByteArrayInputStream("YES".getBytes());
        System.setIn(in);
        assertTrue(test.userInput("EXIT"));
        in = new ByteArrayInputStream("NO".getBytes());
        System.setIn(in);
        assertFalse(test.userInput("EXIT"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("DEPOSIT"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("DEPOSIT"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("DEPOSIT"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("DEPOSIT"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("DEPOSIT"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("WITHDRAWAL"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("WITHDRAWAL"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("WITHDRAWAL"));
        in = new ByteArrayInputStream(simulatedinput.getBytes());
        System.setIn(in);
        assertFalse(test.userInput("WITHDRAWAL"));
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
