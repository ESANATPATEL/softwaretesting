package demo.pkg.test;

import demo.pkg.*;
import org.junit.Test;
import org.mockito.Mock;

import static org.junit.Assert.*;

public class BalanceInquiryTest {

    @Mock
    BalanceInquiry cMock;

    int accountNumber;
    Screen atmScreen;
    BankDatabase atmBankDatabase;
    Keypad atmKeypad;
    CashDispenser atmCashDispenser;

    protected void setUp() {
        accountNumber = 300000;
        atmScreen = new Screen();
        atmBankDatabase = new BankDatabase();
        atmCashDispenser = new CashDispenser();
        atmKeypad = new Keypad();
    }

    @Test
    public void testValidatePin() {
        Withdrawal c = new Withdrawal(123456, atmScreen, atmBankDatabase, atmKeypad, atmCashDispenser);

        assertNotNull(c.getBankDatabase());
        assertEquals(c.getAccountNumber(), 123456);
        assertNotEquals(c.getAccountNumber(), 123457);
    }

    @Test
    public void testWithdrawalScreen() {
        Withdrawal c = new Withdrawal(123456, atmScreen, atmBankDatabase, atmKeypad, atmCashDispenser);

        assertNotNull(c.getBankDatabase());
        assertEquals(c.getBankDatabase(), 123456);
        assertNotEquals(c.getAccountNumber(), 123457);
    }

    @Test
    public void testWithdrawal() {
        Withdrawal c = new Withdrawal(123456, atmScreen, atmBankDatabase, atmKeypad, atmCashDispenser);

        assertNotNull(c.getBankDatabase());
        assertEquals(c.getAccountNumber(), 123456);
        assertNotEquals(c.getAccountNumber(), 123457);
    }


}