package demo.pkg;// BalanceInquiry.java

// Represents a balance inquiry ATM transaction
//@author Sanat Patel
public class BalanceInquiry extends Transaction {
    // BalanceInquiry constructor
    public BalanceInquiry(int userAccountNumber, Screen atmScreen,
                          BankDatabase atmBankDatabase) {
        super(userAccountNumber, atmScreen, atmBankDatabase);
    } // end BalanceInquiry constructor

    // performs the transaction
    @Override
    public void execute() {
        // get references to bank database and screen
        // This can throw a Null PointerException when used to make a call to the getAvailableBalance(AccountNumber) Method
        BankDatabase bankDatabase = getBankDatabase();
        Screen screen = getScreen();

        // get the available balance for the account involved
        //Null check made before making calls to getAvailableBalance(AccountNumber) Method
        double availableBalance = bankDatabase == null ? 0.0 : bankDatabase.getAvailableBalance(getAccountNumber());

        // get the total balance for the account involved
        double totalBalance =
                bankDatabase.getTotalBalance(getAccountNumber());

        // display the balance information on the screen
        screen.displayMessageLine("\nBalance Information:");
        screen.displayMessage(" - Available balance: ");
        screen.displayDollarAmount(availableBalance);
        screen.displayMessage("\n - Total balance:     ");
        screen.displayDollarAmount(totalBalance);
        screen.displayMessageLine("");
    } // end method execute
} // end class BalanceInquiry
